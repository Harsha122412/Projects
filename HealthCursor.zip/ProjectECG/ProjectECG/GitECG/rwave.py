import pandas as pd
import numpy as np
from scipy.signal import find_peaks
import matplotlib.pyplot as plt

df = pd.read_csv("ECG.csv")
time = df.iloc[:, 0].values
filtered_ecg = df.iloc[:, 2].values
sampling_rate = 500

peaks, _ = find_peaks(
    filtered_ecg,
    height=np.mean(filtered_ecg) + 2*np.std(filtered_ecg),
    distance=0.6 * sampling_rate
)
r_peaks = peaks

r_times = time[r_peaks]
amplitudes = filtered_ecg[r_peaks]
rr_intervals = np.diff(r_times) * 1000

print("\nR-Wave Detection Results:")
print(f"{'Index':<10} {'Time (s)':<15} {'Amplitude (mV)':<15} {'RR Interval (ms)':<15}")
print("-" * 55)
for i in range(len(r_peaks)):
    rr = rr_intervals[i-1] if i > 0 else np.nan
    print(f"{i:<10} {r_times[i]:<15.3f} {amplitudes[i]:<15.3f} {rr if not np.isnan(rr) else 'N/A':<15}")

plt.figure(figsize=(12, 6))
plt.plot(time, filtered_ecg, label='Filtered ECG', linewidth=1)
plt.scatter(r_times, amplitudes, color='red', label='R Peaks')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude (mV)')
plt.title('ECG with R-Wave Timestamps')
plt.legend()
plt.grid()
plt.show()

print(f"\nSummary:")
print(f"- Total R-waves detected: {len(r_peaks)}")
print(f"- Average RR interval: {np.nanmean(rr_intervals):.2f} ms")
print(f"- Heart rate: {60 / (np.nanmean(rr_intervals) / 1000):.2f} bpm")