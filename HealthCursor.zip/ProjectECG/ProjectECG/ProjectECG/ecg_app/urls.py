from django.urls import path
from . import views

urlpatterns= [
    path('',views.homepage),
    path('ourteam',views.ourteam),
    path('ecgpage',views.ecgpage),
    path('emgpage',views.emgpage),
    path('eegpage',views.eegpage),
    path('history',views.history),
]