from django.shortcuts import render

# Create your views here.
def homepage(request):
    return render(request,'homepage.html')

def ourteam(request):
    return render(request,'ourteam.html')

def ecgpage(request):
    return render(request,'ecgpage.html')

def emgpage(request):
    return render(request,'emgpage.html')

def eegpage(request):
    return render(request,'eegpage.html')

def history(request):
    return render(request,'history.html')

