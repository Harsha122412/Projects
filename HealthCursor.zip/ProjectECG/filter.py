import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import DictionaryLearning
from sklearn.metrics import mean_squared_error

# Configuration
CSV_PATH = 'ECG.csv'  # Update path to your CSV
FS = 500                   # 500Hz sampling
WINDOW_SIZE = int(0.5 * FS)  # 0.5-second windows (250 samples)

def load_ecg_data():
    """Load and validate ECG data"""
    try:
        df = pd.read_csv(CSV_PATH)
        time = pd.to_numeric(df.iloc[:,0]).values
        raw = pd.to_numeric(df.iloc[:,1]).values
        ref = pd.to_numeric(df.iloc[:,2]).values
        
        # Ensure proper length
        if len(time) != len(raw) or len(raw) != len(ref):
            raise ValueError("Columns have different lengths")
            
        print(f"Loaded {len(time)} samples at {FS}Hz")
        return time, raw, ref
        
    except Exception as e:
        print(f"Data loading error: {e}")
        exit()

def build_ecg_codebook(sig_len, fs):
    """Create optimized dictionary for ECG signals"""
    t = np.arange(sig_len)/fs
    basis = []
    
    # Add QRS-like components (1-20Hz)
    for f in np.linspace(1, 20, 10):
        basis.append(np.sin(2*np.pi*f*t))
        basis.append(np.cos(2*np.pi*f*t))
    
    # Add noise components
    for f in [0.5, 50, 60]:  # BW and PLI frequencies
        basis.append(np.sin(2*np.pi*f*t))
        basis.append(np.cos(2*np.pi*f*t))
        
    return np.column_stack(basis + [np.eye(sig_len)])

def process_ecg(signal, fs):
    """Main processing pipeline"""
    processed = np.zeros_like(signal)
    
    for i in range(0, len(signal), WINDOW_SIZE):
        chunk = signal[i:i+WINDOW_SIZE]
        if len(chunk) < WINDOW_SIZE:
            processed[i:i+WINDOW_SIZE] = chunk
            continue
            
        # 1. Build codebook
        cb = build_ecg_codebook(len(chunk), fs)
        
        # 2. Sparse decomposition with conservative settings
        dl = DictionaryLearning(
            n_components=cb.shape[1],
            alpha=0.01,  # Less aggressive sparsity
            fit_algorithm='lars',
            transform_algorithm='lasso_lars',
            max_iter=100,
            tol=1e-4
        )
        
        try:
            coeffs = dl.fit_transform(chunk.reshape(1,-1), cb.T).flatten()
            reconstructed = cb @ coeffs
            
            # 3. Preserve signal dynamics
            processed[i:i+WINDOW_SIZE] = 0.7*reconstructed + 0.3*chunk
            
        except:
            processed[i:i+WINDOW_SIZE] = chunk
    
    return processed

# Main execution
time, raw, ref = load_ecg_data()
processed = process_ecg(raw, FS)

# Calculate metrics
valid_mask = ~np.isnan(ref) & ~np.isnan(processed)
mse = mean_squared_error(ref[valid_mask], processed[valid_mask])
corr = np.corrcoef(ref[valid_mask], processed[valid_mask])[0,1]
snr_imp = 10*np.log10(np.var(raw[valid_mask])/mse)

print(f"\nProcessing Results:")
print(f"MSE: {mse:.6f}")
print(f"Correlation: {corr:.4f}")
print(f"SNR Improvement: {snr_imp:.2f} dB")

# Visualization
plt.figure(figsize=(15,8))
plt.subplot(2,1,1)
plt.plot(time, raw, 'b', alpha=0.5, label='Raw')
plt.plot(time, processed, 'r', label='Processed')
plt.legend()
plt.title("ECG Signal Processing")

plt.subplot(2,1,2)
plt.plot(time, ref, 'g', alpha=0.7, label='Reference')
plt.plot(time, processed, 'r', alpha=0.5, label='Processed')
plt.legend()
plt.xlabel("Time (s)")
plt.title("Comparison with Reference")

plt.tight_layout()
plt.show()