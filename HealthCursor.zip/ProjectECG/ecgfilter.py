import numpy as np
import pandas as pd
from scipy.optimize import minimize
import matplotlib.pyplot as plt

class ECGNoiseDetector:
    def __init__(self, fs=250):
        """Initialize with configurable sampling rate"""
        self.BW_RANGE = (0, 1)
        self.LF_RANGE = (1, 6) 
        self.PLI_RANGE = (47, 53)
        self.HF_RANGE = None
        self.THRESHOLDS = {
            'BW': 0.1, 'PLI': 0.05,
            'HF_MEDIAN': 0.02, 'HF_ZCR': 5,
            'AWGN_RATIO': 0.8
        }
        self.fs = int(fs)  # Ensure sampling rate is integer

    def load_ecg_data(self, file_path):
        """Load data with every other sample and halve sampling rate"""
        try:
            df = pd.read_csv(file_path)
            if len(df.columns) < 3:
                raise ValueError("CSV must have at least 3 columns")
                
            # Take every other sample
            t = df.iloc[::2, 0].values
            x_unfiltered = df.iloc[::2, 1].values
            x_filtered = df.iloc[::2, 2].values
            
            # Calculate and halve sampling rate
            if len(df.iloc[:, 0]) > 1:
                original_fs = 1/np.mean(np.diff(df.iloc[:, 0].values))
                self.fs = int(original_fs // 2)  # Ensure integer
            
            return t, x_unfiltered, x_filtered
        except Exception as e:
            print(f"Data loading error: {str(e)}")
            raise

    def _generate_basis(self, P, f_range, name):
        """Generate basis functions"""
        if f_range is None:
            return np.eye(P)
            
        f_min, f_max = f_range
        K = int(np.floor(2*P*f_max/self.fs)) - int(np.floor(2*P*f_min/self.fs))
        K = max(1, K)
        
        basis_sin = np.zeros((P, K))
        basis_cos = np.zeros((P, K))
        
        for i in range(K):
            freq_bin = i + int(np.floor(2*P*f_min/self.fs))
            for j in range(P):
                a_i = np.sqrt(0.5) if (freq_bin == P-1) else 1.0
                basis_sin[j,i] = np.sqrt(2/P)*a_i*np.sin((np.pi*(2*j+1)*(freq_bin+1))/(2*P))
                a_i = np.sqrt(0.5) if (freq_bin == 0) else 1.0
                basis_cos[j,i] = np.sqrt(2/P)*a_i*np.cos((np.pi*(2*j+1)*freq_bin)/(2*P))
        
        return np.hstack([basis_sin, basis_cos])

    def build_codebooks(self, P):
        """Build all codebooks"""
        self.codebooks = {
            'BW': self._generate_basis(P, self.BW_RANGE, 'BW'),
            'LF': self._generate_basis(P, self.LF_RANGE, 'LF'),
            'PLI': self._generate_basis(P, self.PLI_RANGE, 'PLI'),
            'HF': self._generate_basis(P, self.HF_RANGE, 'HF')
        }
        
        # Track indices
        start = 0
        self.component_indices = {}
        for name in ['BW', 'LF', 'PLI', 'HF']:
            end = start + self.codebooks[name].shape[1]
            self.component_indices[name] = slice(start, end)
            start = end
            
        return np.hstack(list(self.codebooks.values()))

    def _sparse_decomposition(self, x):
        """Optimized decomposition"""
        P = len(x)
        Phi = self.build_codebooks(P)
        
        def objective(alpha):
            return np.linalg.norm(Phi @ alpha - x)**2 + 0.1*np.linalg.norm(alpha, 1)
        
        alpha0 = np.zeros(Phi.shape[1])
        result = minimize(objective, alpha0, method='L-BFGS-B',
                        options={'maxiter': 500, 'maxls': 50})
        
        return result.x

    def decompose(self, x):
        """Signal decomposition"""
        alpha = self._sparse_decomposition(x)
        components = {}
        
        for name in self.codebooks:
            coeffs = alpha[self.component_indices[name]]
            components[name] = self.codebooks[name] @ coeffs
        
        # Ensure all components match input length
        target_len = len(x)
        for name in components:
            if len(components[name]) != target_len:
                components[name] = np.pad(components[name], (0, target_len - len(components[name])))
        
        components['residual'] = x - sum(components.values())
        return components

    def _analyze_hf_blocks(self, x):
        """HF analysis with 10% overlap"""
        block_size = int(round(0.1 * self.fs))  # 100ms in samples
        block_shift = max(1, int(block_size * 0.9))  # 10% overlap
        num_blocks = max(1, (len(x) - block_size) // block_shift + 1)
        noisy_blocks = 0
        
        for k in range(num_blocks):
            start = k * block_shift
            end = start + block_size
            block = x[start:end]
            
            med = np.median(np.abs(block))
            zcr = len(np.where(np.diff(np.sign(block)))[0])
            
            if (med > self.THRESHOLDS['HF_MEDIAN'] or 
                zcr > self.THRESHOLDS['HF_ZCR']):
                noisy_blocks += 1
        
        ratio = noisy_blocks / num_blocks if num_blocks > 0 else 0
        return {'num_noisy_blocks': noisy_blocks, 'awgn_ratio': ratio}

    def detect_noises(self, components):
        """Noise detection with improved thresholds"""
        results = {'BW': False, 'PLI': False, 'MA': False, 'AWGN': False}
        
        # Baseline wander detection
        x_B = components['BW']
        results['BW'] = np.max(np.abs(x_B)) >= self.THRESHOLDS['BW']
        
        # Power line interference detection
        x_P = components['PLI']
        if np.max(np.abs(x_P)) >= self.THRESHOLDS['PLI']:
            k = self._calculate_kurtosis(x_P)
            hzcrr = self._calculate_hzcrr(x_P)
            
            if hzcrr == 0 and round(k) == 3:
                results['PLI'] = True
            elif hzcrr > 0:
                results['MA'] = True
            elif round(k) == 3:
                results['AWGN'] = True
        
        # HF noise detection
        x_H = components['HF']
        block_stats = self._analyze_hf_blocks(x_H)
        
        if block_stats['num_noisy_blocks'] > 0:
            if block_stats['awgn_ratio'] >= self.THRESHOLDS['AWGN_RATIO']:
                results['AWGN'] = True
            else:
                results['MA'] = True
                
        return results

    def reconstruct_clean_ecg(self, x, components, noise_results):
        """Reconstruct clean ECG signal"""
        clean_ecg = x.copy()
        
        if noise_results['BW']:
            clean_ecg -= components['BW']
        if noise_results['PLI']:
            clean_ecg -= components['PLI']
        if noise_results['MA'] or noise_results['AWGN']:
            clean_ecg -= components['HF']
            
        return clean_ecg

    def _calculate_kurtosis(self, x):
        """Calculate kurtosis of signal"""
        n = len(x)
        m = np.mean(x)
        numerator = np.sum((x - m)**4) / n
        denominator = (np.sum((x - m)**2) / n)**2
        return numerator / denominator

    def _calculate_hzcrr(self, x):
        """Calculate high zero-crossing rate ratio"""
        block_size = int(round(0.1 * self.fs))
        num_blocks = len(x) // block_size
        zcr = []
        
        for n in range(num_blocks):
            segment = x[n*block_size:(n+1)*block_size]
            zcr.append(len(np.where(np.diff(np.sign(segment)))[0]))
        
        avg_zcr = np.mean(zcr)
        hzcrr = np.mean([1 if z > 1.5*avg_zcr else 0 for z in zcr])
        return hzcrr

def plot_results(t, x_unfiltered, x_filtered, components, noise_results, clean_ecg):
    """Enhanced visualization"""
    fig, axs = plt.subplots(6, 1, figsize=(15, 18), sharex=True)
    
    # 1. Baseline Wander
    axs[0].plot(t, components['BW'], 'b')
    axs[0].set_title(f"Baseline Wander - {'Detected' if noise_results['BW'] else 'Not detected'}")
    
    # 2. Power Line Interference
    axs[1].plot(t, components['PLI'], 'r')
    axs[1].set_title(f"PLI - {'Detected' if noise_results['PLI'] else 'Not detected'}")
    
    # 3. High Frequency Noise
    hf_status = 'MA' if noise_results['MA'] else ('AWGN' if noise_results['AWGN'] else 'Clean')
    axs[2].plot(t, components['HF'], 'm')
    axs[2].set_title(f"HF Noise - {hf_status}")
    
    # 4. Muscle Artifact
    axs[3].plot(t, components['HF'] if noise_results['MA'] else np.zeros_like(t), 
               'orange' if noise_results['MA'] else 'gray')
    axs[3].set_title("Muscle Artifact" if noise_results['MA'] else "No Muscle Artifact")
    
    # 5. Filtering Comparison
    axs[4].plot(t, x_filtered, 'b', label='Provided Filtered', alpha=0.8)
    axs[4].plot(t, clean_ecg, 'g', label='Our Filtered')
    axs[4].set_title('Filtering Comparison')
    axs[4].legend()
    
    # 6. Original vs Filtered
    axs[5].plot(t, x_unfiltered, 'k', label='Original', alpha=0.7)
    axs[5].plot(t, clean_ecg, 'g', label='Our Filtered')
    axs[5].set_title('Original vs Filtered')
    axs[5].legend()
    
    for ax in axs:
        ax.grid(True)
        ax.set_ylabel('Amplitude (mV)')
    axs[-1].set_xlabel('Time (s)')
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    print("ECG Noise Detection System")
    print("With 10% overlapping blocks and robust error handling")
    
    try:
        detector = ECGNoiseDetector()
        t, x_unfiltered, x_filtered = detector.load_ecg_data('ECG.csv')
        print(f"Processing {len(t)} samples at {detector.fs}Hz")
        
        components = detector.decompose(x_unfiltered)
        noise_results = detector.detect_noises(components)
        clean_ecg = detector.reconstruct_clean_ecg(x_unfiltered, components, noise_results)
        
        print("\nNoise Detection Results:")
        print(f"- BW: {noise_results['BW']}\n- PLI: {noise_results['PLI']}")
        print(f"- MA: {noise_results['MA']}\n- AWGN: {noise_results['AWGN']}")
        
        plot_results(t, x_unfiltered, x_filtered, components, noise_results, clean_ecg)
        
    except Exception as e:
        print(f"\nError: {str(e)}")
        print("Debug Tips:")
        print("1. Verify CSV format (time,unfiltered,filtered columns)")
        print("2. Check time values are uniform")
        print("3. Ensure adequate data length (>1 second of data)")
        print("4. Validate no NaN/inf values in input")