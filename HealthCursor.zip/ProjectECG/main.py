import pandas as pd
import matplotlib.pyplot as plt

def read_csv(file_path):
    try:
        data = pd.read_csv(file_path)
        return data
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def write_csv(file_path, data):
    try:
        data.to_csv(file_path, index=False)
    except Exception as e:
        print(f"An error occurred: {e}")

def plot_waveform(data, column_name):
    try:
        if column_name not in data.columns:
            print(f"Error: Column '{column_name}' not found in the data.")
            return
        plt.plot(data[column_name])
        plt.title(f"Waveform of {column_name}")
        plt.xlabel("Index")
        plt.ylabel("Value")
        plt.grid(True)
        plt.show()
    except Exception as e:
        print(f"An error occurred while plotting: {e}")

